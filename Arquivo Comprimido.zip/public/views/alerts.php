<section class="container alerts">        
    <div class="alert alert-success" role="alert">
        <span>História excluída com sucesso</span>
    </div>
</section>