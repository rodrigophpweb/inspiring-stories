<footer class="footer mt-auto py-3 bg-body-tertiary">
    <div class="container">
        <p class="text-body-secondary text-center">Senac São Paulo - Senac na Minha História</p>
    </div>
    <section class="modals">
        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h1 class="modal-title fs-5" id="exampleModalLabel">Modal title</h1>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                    ...
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="button" class="btn btn-primary">Save changes</button>
                    </div>
                </div>
            </div>
        </div>
    </section>
</footer>

<!-- Modal Variable
https://getbootstrap.com/docs/5.3/components/modal/#varying-modal-content:~:text=%3C/div%3E-,Varying%20modal%20content,-Have%20a%20bunch

-->