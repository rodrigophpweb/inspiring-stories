<?php foreach ($areasOfInterests as $area): ?>
    <div class="form-check form-check-inline">
        <input class="form-check-input" type="checkbox" id="area-<?php echo $area['id']; ?>" value="<?php echo htmlspecialchars($area['name']); ?>">
        <label class="form-check-label" for="area-<?php echo $area['id']; ?>"><?php echo htmlspecialchars($area['name']); ?></label>
    </div>
<?php endforeach; ?>